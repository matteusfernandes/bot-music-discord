const start = require('./src/index');

start();
